#include "PublicFile.h"
PublicNum::CMode PublicNum::c_mode = CMode::FixedPoint;//CPP�ōēx��`���Ȃ��ƃG���[
//PublicNum::DMode PublicNum::d_mode = DMode::LogOff;
int PublicNum::LightFeather_Count = 0;
int PublicNum::Feather_Count = 0;
bool PublicNum::log_passage = false;
bool PublicNum::log_pos = false;